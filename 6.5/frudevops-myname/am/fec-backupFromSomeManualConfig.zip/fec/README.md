# FEC Portal Configuration Folder

The `fec` folder is for storing the configuration for the AM instance.

You need to update the custom `.yaml` file for Amster with the updated path.

Amster needs to know where to get the configuration for AM from.

Be sure to push your changes to the upstream master fork.

If you sync changes from a running AM instance, then you need to merge the autosave branch back to master and pull the master back to the clone.

Note that other methods are possible for those who know Git better than myself (which should be a lot of people :-)).


